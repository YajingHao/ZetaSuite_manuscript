package HGPValue;
use strict;
use vars qw($VERSION @ISA @EXPORT @EXPORT_OK);
use Carp;

require Exporter;
require AutoLoader;

@ISA = qw(Exporter AutoLoader);
# Items to export into callers namespace by default. Note: do not export
# names by default without a very good reason. Use EXPORT_OK instead.
# Do not simply export all your public functions/methods/constants.
@EXPORT = qw();
$VERSION = '0.01';

my @COEFF= (76.18009172947146,-86.50532032941677, 24.014098240083091,-1.231739572450155,0.1208650973866179e-2,-0.5395239384953e-5);
my @A=undef;

sub new {
  my ($pkg) = @_;
  my $class = ref($pkg) || $pkg;
  @A=();
  for (my $i=0; $i<101; $i++) { $A[$i]=-1.0; }
  my $self={};
  return bless $self, $class;
}

sub gammln {
  my $xx = shift;
  my ($y,$x,$j,$tmp,$ser);
  $y=$xx;
  $x=$xx;
  $tmp=$x+5.5;
  $tmp -= ($x+0.5)*log($tmp);
  $ser = 1.000000000190015;
  for (my $j=0; $j<6; $j++) {
    $y+=1;
    $ser+=$COEFF[$j]/$y;
  }
  return -$tmp+log(2.5066282746310005*$ser/$x);
}

sub factln {
  my $nn = shift;
  if ($nn < 0) {
    print "HELLO\n";
    exit;
  } elsif ($nn <= 1) {
    return 0.0;
  } elsif ($nn <= 100) {
    if ($A[$nn] != -1.0) {
      return $A[$nn];
    } else {
      $A[$nn] = gammln($nn+1.0);
      return $A[$nn];
    }
  } else {
    return gammln($nn+1.0);
  }
}

sub bicoln {
  my ($nn, $k) = @_;
  return factln($nn)-factln($k)-factln($nn-$k);
}

# N: Total number of gene
# n2: n2 out of N genes are in a particular category
# n1: randomly select n1 out of N genes
# n: n out of the n1 randomly selected genes share the same category as n2

sub pvalue_previous {
  my ($self, $N, $n1, $n2, $n) = @_;
  my ($minIndex,$c3,$c1,$c2,$P);
  return 1.0 if ($n>$n1 || $n>$n2 || $n>$N || $n1 > $N || $n2 > $N);
  # instead of quiting, reporting insignificant
  $minIndex = ($n1<$n2)?$n1:$n2;
  $c3 = bicoln($N,$n1);
  $P = 0.0;
  for (my $i=$n; $i<=$minIndex; $i++) {
    $c1=bicoln($n2,$i);
    $c2=bicoln($N-$n2,$n1-$i);
    $P+=exp($c1+$c2-$c3);
  }
  $P=1 if $P>1;
  return $P;
}

sub pvalue {
  my ($self, $N, $n1, $n2, $n) = @_;
  my ($minIndex,$c3,$P,$x,$term,$l_left);
  $minIndex = ($n1<$n2)?$n1:$n2;
  $l_left=($n*1.0/$n1<$n2*1.0/$N && $n<($minIndex-$n+1));
  $c3 = bicoln($N,$n1);
  $term=1.0;
  $P=$l_left?0.0:1.0; # when l_left, do not include pvalue2(N,n1,n2,n) itself
  if ($l_left) {
    for (my $x=$n-1; $x>=0; $x--) {
      $term*=($x+1.0)*($N-$n2-$n1+$x+1.0)/($n1-$x)/($n2-$x);
      $P+=$term;
    }
  } else {
    for (my $x=$n+1; $x<=$minIndex; $x++) {
      $term*=($n1-$x+1.0)*($n2-$x+1.0)/$x/($N-$n2-$n1+$x);
      $P+=$term;
    }
  }
  $P*=exp(bicoln($n2,$n)+bicoln($N-$n2,$n1-$n)-$c3);
  return $l_left?(1.0-$P):$P;
}

#return the incomplete gamma function P(a,x) evaluated by its series representation
sub gser {
  my ($a, $x, $gln) = @_;
  my ($sum,$del,$ap);
  my $ITMAX=100;
  my $EPS=0.0000003;
  $gln=gammln($a) unless defined($gln);
  if ($x<=0) {
    return undef if ($x<0);
    return 0.0;
  } else {
    $ap=$a;
    $sum=1.0/$a;
    $del=$sum;
    for (my $n=1; $n<=$ITMAX; $n++) {
      $ap+=1;
      $del*=$x/$ap;
      $sum+=$del;
      if (abs($del)<abs($sum)*$EPS) {
        return $sum*exp(-$x+$a*log($x)-$gln);
      }
    }
    return undef;
  }
}

#return the incomplete gamma function Q(a,x) evaluated by its continuous fraction representation
sub gcf {
  my ($a, $x, $gln) = @_;
  my $ITMAX=100;
  my $EPS=0.0000003;
  my $FPMIN=1e-30;
  my ($i,$an,$b,$c,$d,$del,$h);
  $gln=gammln($a) unless defined($gln);
  $b=$x+1.0-$a;
  $c=1/$FPMIN;
  $d=1/$b;
  $h=$d;
  for ($i=1; $i<=$ITMAX; $i++) {
    $an=-$i*($i-$a);
    $b+=2;
    $d=$an*$d+$b;
    if (abs($d)<$FPMIN) { $d=$FPMIN; }
    $c=$b+$an/$c;
    if (abs($c)<$FPMIN) { $c=$FPMIN; }
    $d=1/$d;
    $del=$d*$c;
    $h*=$del;
    last if (abs($del-1)<$EPS);
  }
  return undef if $i>$ITMAX;
  return exp(-$x+$a*log($x)-$gln)*$h;
}

sub gammq {
  my ($a, $x, $gln) = @_;
  return undef if ($x<0||$a<=0);
  $gln=gammln($a) unless defined($gln);
  if ($x<($a+1.0)) {
    return 1-gser($a,$x,$gln);
  } else {
    return gcf($a,$x,$gln);
  }
}

sub chi2 {
  my ($self, $df, $chi2) = @_;
  return gammq($df/2.0, $chi2/2.0);
}

1;
